<?php

$count=0;
$counter=0;

$p=$_POST['initial'];
$r=$_POST['destination'];
$ip="localhost";              // Server IP
$username="root";			  	
$pass="";
$con=new mysqli($ip,$username,$pass,'Transportation') or die("error".mysql_error);
// $con=mysql_connect($ip,$username,$pass) or die("error".mysql_error);

// mysql_select_db("Transportation",$con);

if ($p&&$r)
	$sel=mysqli_query($con,"select count(*) AS c from `Trucks` WHERE `Initial Place`='".$p."' AND `Destination`='".$r."'");
else if ($p)
	$sel=mysqli_query($con,"select count(*) AS c from `Trucks` WHERE `Initial Place`='".$p."' ");
else if ($r)
	$sel=mysqli_query($con,"select count(*) AS c from `Trucks` WHERE `Destination`='".$r."'");
else
	$sel=mysqli_query($con,"select count(*) AS c from `Trucks`");

$sel=mysqli_fetch_assoc($sel);

$count=$sel['c'];

if ($p&&$r)
	$sell=mysqli_query($con,"select * from `Trucks` WHERE `Initial Place`='".$p."' AND `Destination`='".$r."'");
else if ($p)
	$sell=mysqli_query($con,"select * from `Trucks` WHERE `Initial Place`='".$p."' ");
else if ($r)
	$sell=mysqli_query($con,"select * from `Trucks` WHERE `Destination`='".$r."'");
else
	$sell=mysqli_query($con,"select * from `Trucks`");

$arr = array();
for ($x=0; $x<$count; $x++)
  {
		$arr[$x] = array();
  }
$qq=0;
//$sell=mysqli_fetch_assoc($sell);
while($log=mysqli_fetch_array($sell))
{

	$arr[$counter][0]=$log['Name'];$arr[$counter][1]=$log['Phone number'];$arr[$counter][2]=$log['Initial Place'];$arr[$counter][3]=$log['Destination'];$arr[$counter][4]=$log['Time Left in Departure'];;
	$counter+=1;
}

?>
