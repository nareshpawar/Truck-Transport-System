<?php
$ip="localhost";              // Server IP
$username="root";			  	
$pass="";
?>
