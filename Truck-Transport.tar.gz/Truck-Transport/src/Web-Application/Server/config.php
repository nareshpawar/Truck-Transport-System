<?php
$IP="localhost";
$user="root";
$pass="";
$db="Transportation";
?>
