-- phpMyAdmin SQL Dump
-- version 4.0.9
-- Host: localhost
-- Server version: 5.6.14
-- PHP Version: 5.5.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

-- Database: `Transportation`
--

-- --------------------------------------------------------


CREATE TABLE IF NOT EXISTS `Trucks` (
  `Name` varchar(50) NOT NULL,
  `Phone number` bigint(10) NOT NULL,
  `Initial Place` varchar(50) NOT NULL,
  `Destination` varchar(50) NOT NULL,
  `Time Left in Departure` int(11) NOT NULL,
  UNIQUE KEY `Phone number` (`Phone number`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Trucks`
--

INSERT INTO `Trucks` (`Name`, `Phone number`, `Initial Place`, `Destination`, `Time Left in Departure`) VALUES
('Kaushal', 6666666666, 'Pune', 'Surat', 4),
('Arti', 7894567890, 'Ahmednagar', 'Delhi', 72),
('Mohit', 8288909695, 'Pune', 'Pune', 501),
('Jeevan', 8288987154, 'ahmednagar', 'Pune', 262),
('Chimed', 8978654329, 'Ahmednagar', 'Pune', 462),
('Kunal', 8987654789, 'Satara', 'Pune', 462),
('Ankit Khokker', 9501152710, 'Kolhapur', 'Mumbai', 263),
('Sajal', 9501651210, 'Pune', 'Mumbai', 263),
('Aniket Sachdeva', 9501651223, 'Mumbai', 'Pune', 262),
('Mohit Garg', 9501652710, 'Pune', 'Dhule', 261),
('Deepak Chawla', 9501674896, 'Raygad', 'Pune', 261),
('Savyasachi', 9711489399, 'Mumbai', 'Nagpur', 441),
('Agrim Bansal', 9876521430, 'Nashik', 'Satara', 263);

