-- phpMyAdmin SQL Dump
-- version 4.0.9
-- Host: localhost
-- Server version: 5.6.14
-- PHP Version: 5.5.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

--
-- Database: `Transportation`
--

-- --------------------------------------------------------

--
-- Table structure for table `Trucks`
--

CREATE TABLE IF NOT EXISTS `Trucks` (
  `Name` varchar(50) NOT NULL,
  `Phone number` bigint(10) NOT NULL,
  `Initial Place` varchar(50) NOT NULL,
  `Destination` varchar(50) NOT NULL,
  `Waiting Time` int(11) NOT NULL,
  `Times` int(11) NOT NULL,
  UNIQUE KEY `Phone number` (`Phone number`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

